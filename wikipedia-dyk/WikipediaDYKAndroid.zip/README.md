# Wikipedia DYK Share Tool — Android Studio project

This project packages your supplied HTML tool inside an Android WebView, preserving its HTML/CSS/JavaScript UI and article-to-image workflow. Google Analytics 4 tracking ID `G-GC8PGC89NB` has been added to `app/src/main/assets/index.html`.

## Build
1. Extract the ZIP.
2. Open the `WikipediaDYKAndroid` folder in Android Studio.
3. Let Gradle sync (internet required for dependencies).
4. Run on a device/emulator, or choose **Build > Build APK(s)**.

- Minimum Android: Android 7.0 (API 24).
- Internet is required for Wikimedia APIs, remote images and Google Analytics.
- This is a WebView wrapper rather than a native Jetpack Compose rewrite.
- Browser features such as Web Share and clipboard can vary in Android WebView; native sharing integration may be needed if they do not work on a target device.
- Review privacy/consent requirements before releasing analytics-enabled builds.
